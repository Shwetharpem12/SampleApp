package com.example.demoSpringApiProject;

import java.util.List;

//import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demoSpringApiProject.model.userModel.UserDao;
import com.example.demoSpringApiProject.model.userModel.UsersData;



@SpringBootTest
class DemoSpringApiProjectApplicationTests {
	
	@Autowired
	private UserDao userDao;
	

	//@Test
	void addUserDataTest() {
		UsersData userdata = new UsersData();
		userdata.setFirstName("Thanvi");
		userdata.setLastName("Naveen");
		userdata.setEmail("thanvi.acharya@gmail.com");
		userDao.save(userdata);
		
	}
	
	//@Test
	void getAllUsersData() {
		List<UsersData> userdatas = userDao.getAllUsers();
		System.out.println(userdatas);
		
	}

}
