package com.example.demoSpringApiProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoSpringApiProject.model.userModel.UserDao;
import com.example.demoSpringApiProject.model.userModel.UsersData;

@RestController
public class UserController {
	
	@Autowired
	private UserDao userdao;
	
	@GetMapping("/users/get-all")
	public List<UsersData> getAllUsers(){
		return userdao.getAllUsers();
		
	}
	
	@PostMapping("/users/save")
	public void save(@RequestBody UsersData userdata) {
		userdao.save(userdata);
	}

}
