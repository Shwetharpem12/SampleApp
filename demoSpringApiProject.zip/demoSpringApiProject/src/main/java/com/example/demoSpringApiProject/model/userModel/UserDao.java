package com.example.demoSpringApiProject.model.userModel;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.util.Streamable;
import org.springframework.stereotype.Service;

@Service
public class UserDao {
	
	@Autowired
	private UserRepository repository;
	
	public List<UsersData> getAllUsers() {
		List<UsersData> userdatas = new ArrayList<>();
		Streamable.of(repository.findAll())
			.forEach(userdatas::add);
		return userdatas;
	}
	
	public void save(UsersData userdata) {
		repository.save(userdata);
		
	}
	
	public void delete(UsersData userdata) {
		repository.delete(userdata);
	}

}
