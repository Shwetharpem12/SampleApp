package com.example.usersdatademoproject

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.support.multidex.MultiDex
//import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.widget.Button
import android.widget.EditText
//import android.widget.Toast
import com.example.usersdatademoproject.model.UsersData
import com.example.usersdatademoproject.retrofit.RetrofitService
import com.example.usersdatademoproject.retrofit.UsersDataApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

  //  lateinit var txtid : EditText
    //lateinit var txtfirstname : EditText
  //  lateinit var txtlastname : EditText
  //  lateinit var txtemail : EditText
   // lateinit var btnsave : Button
    lateinit var retrofitService: RetrofitService
    lateinit var userdataApi : UsersDataApi


    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }
        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        getMyData()


    }

    private fun getMyData() {
        val txtid = findViewById<EditText>(R.id.txtId)
        val txtfirstname = findViewById<EditText>(R.id.txtFirstName)
        val txtlastname = findViewById<EditText>(R.id.txtLastName)
        val txtemail = findViewById<EditText>(R.id.txtEmail)
        val btnsave = findViewById<Button>(R.id.btnSave)

        var retrofitService = RetrofitService()
        userdataApi = retrofitService.getRetrofit().create(UsersDataApi::class.java)


       // val usersDataApi = retrofitService.getRetrofit().create(UsersDataApi::class.java)
        // usersDataApi = retrofitService.getRetrofit().create(UsersDataApi.javaClass)
        //usersDataApi

        btnsave.setOnClickListener{
            val id = txtid.toString()
            val firstname = txtfirstname.toString()
            val lastname = txtlastname.toString()
            val email = txtemail.toString()

            val userData = UsersData()

            userData.setId(id)
            userData.setFirstname(firstname)
            userData.setLastname(lastname)
            userData.setEmail(email)


            userdataApi.save(userData).enqueue(object : Callback<List<UsersData>?> {
                override fun onResponse(
                    call: Call<List<UsersData>?>,
                    response: Response<List<UsersData>?>
                ) {
                    Log.d("MainActivity","Saved")
                    // Toast.makeText(this@MainActivity,"Saved",Toast.LENGTH_SHORT).show()
                }

                override fun onFailure(call: Call<List<UsersData>?>, t: Throwable) {
                    Log.d("MainActivity", "onFailure : "+t.message)
                }
            })



        }

    }
}

private fun Any.enqueue(callback: Callback<List<UsersData>?>) {

}




