package com.example.usersdatademoproject.retrofit

import com.example.usersdatademoproject.model.UsersData
import retrofit2.http.GET
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST



interface UsersDataApi {

    @GET("/users/get-all")
    fun getAllUsers(): Call<List<UsersData>>

    @POST("/users/save")
    fun save(@Body userData: UsersData): Call<UsersData>


}