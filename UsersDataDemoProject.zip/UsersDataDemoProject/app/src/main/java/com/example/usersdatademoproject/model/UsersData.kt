package com.example.usersdatademoproject.model

class UsersData {

    var id : String  = ""
    var firstname: String = ""
    var lastname : String = ""
    var email: String = ""


    fun getId(id: String): String {
        return id
    }
    @JvmName("setId1")
    fun setId(id: String) {
        this.id = id
    }


    fun getFirstname(firstname: String): String {
        return firstname
    }
    @JvmName("setFirstname1")
    fun setFirstname(firstname: String) {
        this.firstname = firstname
    }

    fun getLastname(lastname: String): String {
        return lastname
    }
    @JvmName("setLastname1")
    fun setLastname(lastname: String) {
        this.lastname = lastname
    }

    fun getEmail(email: String): String {
        return email
    }
    @JvmName("setEmail1")
    fun setEmail(email: String) {
        this.email = email
    }



}