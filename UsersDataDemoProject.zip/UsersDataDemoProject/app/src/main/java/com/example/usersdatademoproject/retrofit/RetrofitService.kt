package com.example.usersdatademoproject.retrofit

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class RetrofitService {


    private lateinit var retrofit : Retrofit

    private fun initializeRetrofit() {
        val retrofit = Retrofit.Builder()
            .baseUrl("http://172.16.57.166:9000")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        
    }

    public fun getRetrofit():Retrofit {
        return retrofit
    }


}